import React, { Component } from 'react'
import { MDBContainer, MDBRow, MDBCol, MDBBtn, MDBIcon } from 'mdbreact';
import "../App.css"

export default class Feedback extends Component {
   constructor(){
     super()
     this.state={
       usrname:"",
       email:"",
       subject:"",
       message:"",
     }
   }
   handleChange=(e)=>{
    
    this.setState({
        [e.target.name]: e.target.value
       
    })}

    handleSubmit=(e)=>{
      e.preventDefault();
      var data = JSON.stringify({"name":this.state.usrname, "email":this.state.email, "subject":this.state.subject, "messages":this.state.message})

      var requestOptions = {
        method: 'POST',
        headers:{'Content-Type':'application/json'},
        redirect: 'follow',
        data: data
      };
      
      fetch("http://127.0.0.1:8000/feedback", requestOptions)
        .then(response => response.text())
        .then(result => console.log(result))
        .catch(error => console.log('error', error));
    }
  
  render() {
        return (
            <div className="center mt-5 content-center pr-5" style={{backgroundColor:"lightskyblue",height:"100vh",width:"100%",borderRadius:"10px",color:"white"}}>
                <MDBContainer>
  <MDBRow>
    <MDBCol md="6">
      <form onSubmit={this.handleSubmit}>
        <p className="h4 text-center mb-4 mt-5"><h1>Write to us</h1></p>
        <label htmlFor="defaultFormContactNameEx" className="grey-text">
          Your name
        </label>
        <input type="text" id="defaultFormContactNameEx" className="form-control" name="usrname" value={this.state.usrname} onChange={this.handleChange} />
        <br />
        <label htmlFor="defaultFormContactEmailEx" className="grey-text">
          Your email
        </label>
        <input type="email" id="defaultFormContactEmailEx" className="form-control" name="email" value={this.state.email} onChange={this.handleChange}/>
        <br />
        <label htmlFor="defaultFormContactSubjectEx" className="grey-text">
          Subject
        </label>
        <input type="text" id="defaultFormContactSubjectEx" className="form-control" name="subject" value={this.state.subject} onChange={this.handleChange} />
        <br />
        <label htmlFor="defaultFormContactMessageEx" className="grey-text">
          Your message
        </label>
        <textarea type="text" id="defaultFormContactMessageEx" className="form-control" rows="3" name="message" value={this.state.message} onChange={this.handleChange}/>
        <div className="text-center mt-4">
                  <MDBBtn className="btn btn-info" outline type="submit">
                    Submit
                    <MDBIcon far icon="paper-plane" className="ml-2" />
                  </MDBBtn>
                </div>
              </form>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
            </div>
        )
    }
}
