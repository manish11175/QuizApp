import React, { Component } from 'react'
import '../App.css';
import Timer from "react-compound-timer"
import { Link } from 'react-router-dom';

export default class Question_Display extends Component {
    constructor(){
        super()
        this.state={
            quescount:1,
            
        }
    }

    handleQues=()=>{
        if(this.state.quescount<10)
         this.setState({
           quescount:this.state.quescount+1
        })
        else{
            this.props.history.push("/section")
        }
      }
    render() {
        return (
            
              <div className="divs"> 
              <div style={{height:"10vh",background:":ghostwhite"}}></div>
              <div className="hero is-primary is-fullheight">
               <div className="hero-body">
               <div className="container ">
               <div className="columns is-mobile is-centered">
               <div className="column is-half">
                <div className=" has-text-centered">
                    <div className="float-right">
                    <Timer
                       initialTime={600000}
                       direction="backward"
>
                      {() => (
                        <React.Fragment>
           
                        <Timer.Minutes /> minutes.
                        <Timer.Seconds /> seconds
            
                           </React.Fragment>
                       )}
                    </Timer> 


                    </div>
                 
                    <h7 className="subtitle has-text-centered is-uppercase is-7 navigation mt-3">QUESTION {this.state.quescount} OF 10</h7>
                   <h5 className="subtitle has-text-centered is-5 mt-4">What does CSS stand for?</h5>
                   <p className="option has-text-grey-dark mt-3">
                      <span className="has-text-weight-bold is-size-5">A</span> Cascading Style Sheets
                     </p>
                     <p className="option has-text-grey-dark">
                     <span className="has-text-weight-bold is-size-5">B</span> Creative Style Sheets
                      </p>
                      <p className="option has-text-grey-dark">
                      <span className="has-text-weight-bold is-size-5">C</span> Computer Style Sheets
                      </p>
                       <p className="option has-text-grey-dark">
                        <span className="has-text-weight-bold is-size-5">D</span>  Colorful Style Sheets
                     </p>
                        <button className="btn btn-success mt-4" onClick={this.handleQues}>Next</button>
                 </div>
                </div>
            </div>
           </div>
         </div>

         </div>

            </div>
        )
    }
}
