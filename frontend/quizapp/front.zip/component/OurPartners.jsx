import React from 'react';
const OurPartners=()=>{
    return(
        <>
        <h1>Hello</h1>
        </>
    )
}
export default OurPartners;