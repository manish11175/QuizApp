import React from 'react';
const Services=()=>{
    return(
        <>
        <h1>Hello</h1>
        </>
    )
}
export default SErvices;