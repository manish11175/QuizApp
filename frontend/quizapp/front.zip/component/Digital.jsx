import React from 'react';
import img from '../Images/digi.jpg';
import img3 from '../Images/backgrounddigital.jpg';
import Footer from "./Footer";
const Digital=()=>{
    return(
        <>
        
        <img src={img} className="w-100" height='350px;'/>
        <div class="about-background ">
        <img src={img3} className="w-100" height='1600px;'/>
       
       <div class="top-left w-50 mx-5">
           <h1 className='heading2 my-4'>Search Engine Optimization (SEO) Services</h1>
           
<p class="text-italic text-white"> There are an assortment of site improvement administrations which offer answers for an assortment of <strong>positioning issues</strong> and lacks. Contingent upon your objectives, and requirements one, or a mix, of the beneath administrations might be ideal for your site.
approaching things from our customers' perspective and anticipating their needs."</p>
<p className='para'>
A site design improvement review can arrive in a differing levels of point of interest and many-sided quality. A basic site review can be as short as a couple pages long, and would address glaring on-page issues, for example, missing titles, and absence of substance. Then again flip side of the range, a thorough site SEO review will be contained many pages (for most bigger destinations.
	

    </p>
      
       </div>
       <div className="center-img w-100">
            <h1 className='head my-4 text-center'>On-Page SEO</h1>
         <p className='par text-white'>On-page or on location website streamlining alludes to SEO methods which are intended to execute the issues and potential issues that a SEO review reveals. This is something which ought to dependably be a piece of all great SEO bundles. On-page SEO addresses an assortment of essential components (as they identify with SEO, for example, page titles, headings, substance and substance association, and inside connection structure.
         <br/><br/>Likewise with a site SEO review, there are fundamental, and additionally complete administrations with regards to on-page website improvement. At the most fundamental level, an on-page streamlining effort can be a one-time venture which incorporates proposals created through a review, and the execution thereof. This kind of on-page improvement would by and large focus on the landing page and a couple of other vital pages on the site. More extensive on-page site improvement battles will utilize the discoveries of a very nitty gritty site SEO review, and screen results to control progressing changes to the on-page streamlining.</p>
</div>

      <div className="bottom ">
          <div className="m-4">
          <h1 className='heading5 text-center text-white'>Link Development (Link Building)</h1>
           <p className='para3'>Link improvement is a standout amongst the most dubious and frequently talked (composed) about points of the website streamlining industry. Since backlinks are the most fundamental segment of any site improvement battle, and in the meantime the most tedious and therefore most costly (expecting they are great quality connections and not simply irregular catalog entries and web journal remark spam) part, unavoidably, there are numerous administration suppliers who offer reasonable third party referencing administrations so as to pull in and inspire potential customers. Such plans incorporate huge volumes of index entries (e.g., 200 registry entries for each month), useless web journal and discussion remark spam (e.g., 100 online journal joins for each month), or article composing and entries which bring about amazingly low quality substance distributed on similarly low-quality article catalogs which contribute in no positive approach to positioning upgrades. So in the event that somebody is citing you a $500 every month website streamlining administrations which incorporates expansive volumes of registry entries, blog entries, articles, blog/gathering remarks etc, all you will do is discarding your cash. This is not to say that you can't get join work for $500 every month; notwithstanding, it won't be for a huge volume of connections.

Great quality connection advancement work concentrates on quality as opposed to amount. An all around looked into and significant, great quality connection is worth ordinarily more than many free registry entries.

The basics of third party referencing are, have dependably been and dependably will be, founded on great quality (i.e., helpful, fascinating, stimulating, instructive) content. Since if there is no great substance on your site that individuals can connection to, it will be extremely hard to persuade them to do as such.<br/>A far reaching website streamlining effort will have the greater part of the above components, however it will likewise fuse other critical administrations, for example, catchphrase research, positioning reports, movement reports, and change following.  </p>
      
          </div>
          </div>
      
      
        
        </div>
        <Footer/>
       
        </>
    )
}
export default Digital;