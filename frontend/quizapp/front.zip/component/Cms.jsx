import React from 'react';
import img from '../Images/cms3.jpeg';
import Footer from "./Footer";
const CMS=()=>{
    return(
        <>
       <img src={img} className="w-100" height='350px;'/>
       <h1 className='header-c text-center my-4'>Wordpress</h1>
      <div className='container'> <p className='pa'>The future for full functional websites with an integrated blog system and built in CMS (content Management System) is a website designed on the wordpress platform. Wordpress blogs are powerful online marketing tools that help establish you as an expert in your industry. The capabilities of using Wordpress as a website are endless. Aishani Technology understands the vast amount of potential that Wordpress has on the impact of your company's website and for this reason we recommend a Wordpress designed site over any other. Aishani Technology team have invested large amounts of time to ensure we stay up to date and competitive as one of the top Wordpress design firms around.

<br/><br/>Wordpress is extremely user friendly and teaching anyone how to use Wordpress is an easy task. The user can edit their home page, blog posts or any other page with ease by just editing the text or elements in the back end of the program.</p>
       </div> 
       <h1 className='header-c text-center my-4'>Drup</h1>
       <div className='container'my-5> <p className='pa'>The future for full functional websites with an integrated blog system and built in CMS (content Management System) is a website designed on the wordpress platform. Wordpress blogs are powerful online marketing tools that help establish you as an expert in your industry. The capabilities of using Wordpress as a website are endless. Aishani Technology understands the vast amount of potential that Wordpress has on the impact of your company's website and for this reason we recommend a Wordpress designed site over any other. Aishani Technology team have invested large amounts of time to ensure we stay up to date and competitive as one of the top Wordpress design firms around.

<br/><br/>Meeting you with quantifiable innovation advantages, Aishani Technology team have a significant ordeal in building profoundly vigorous, component stuffed and secluded Drupal arrangements. With consummate assessment of your prerequisites and an exhaustive engagement in Drupal's center, we give custom Drupal CMS improvement, expansions advancement, topic customization and support benefits that take into account heap industry verticals.<br/>With bespoke Drupal entrances and web applications that advance the uniqueness of your business thought, we make items that make the activity of incorporating novel apparatuses and systems in your structure more favorable and compensating. We weave development and practicability together to make a business esteem that is unrivaled. Our propulsive and adaptable Drupal outsourcing administrations ensure leap forward results and help you take complete control of your web advancement cost and the related dangers. The troublesome floats of the business sector stop to influence your execution measurements contrarily, since you are pre-outfitted with the techniques to manage them unequivocally</p>
       </div>
       <Footer/> 
       </>
       
       
    )
}
export default CMS;