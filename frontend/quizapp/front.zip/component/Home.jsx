import React from 'react';
import Cards from './Cards';
import Crowsal from './Crowsal';

import Footer from "./Footer";
const Home=()=>{
    return(
        <>
        
        <Crowsal/>
        <Cards/>

       <Footer/>
        </>
    )
}
export default Home;