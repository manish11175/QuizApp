import React, { Component } from 'react'

export default class Thankyou extends Component {
    render() {
        return (
            <div>
                Thankyou
            </div>
        )
    }
}
